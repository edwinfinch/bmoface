#include <pebble.h>
#include "main.h"
#include "data_layer.h"

TextLayer* text_layer_init(GRect location, bool is_date)
{
	TextLayer *layer = text_layer_create(location);
	text_layer_set_text_color(layer, GColorBlack);
	text_layer_set_background_color(layer, GColorClear);
	text_layer_set_text_alignment(layer, GTextAlignmentCenter);
	text_layer_set_font(layer, fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_IMPACT_32)));
	if(is_date){
		text_layer_set_font(layer, fonts_get_system_font(FONT_KEY_GOTHIC_14));
	}
	return layer;
}

void outline_proc(Layer *l, GContext *ctx){
	graphics_draw_rect(ctx, GRect(0, 0, 144, 168));
	graphics_draw_rect(ctx, GRect(1, 1, 142, 166));
	//top left corner rounding
	graphics_draw_pixel(ctx, GPoint(2, 2));
	graphics_draw_pixel(ctx, GPoint(3, 2));
	graphics_draw_pixel(ctx, GPoint(2, 3));
	//top right corner rounding
	graphics_draw_pixel(ctx, GPoint(141, 2));
	graphics_draw_pixel(ctx, GPoint(140, 2));
	graphics_draw_pixel(ctx, GPoint(141, 3));
	//bottom right
	graphics_draw_pixel(ctx, GPoint(141, 165));
	graphics_draw_pixel(ctx, GPoint(141, 164));
	graphics_draw_pixel(ctx, GPoint(140, 165));
	//bottom left
	graphics_draw_pixel(ctx, GPoint(2, 165));
	graphics_draw_pixel(ctx, GPoint(2, 164));
	graphics_draw_pixel(ctx, GPoint(3, 165));
}
	
int calculate_happiness(){
	
}

void refresh(){
	gbitmap_destroy(face_icon);
	face_icon = gbitmap_create_with_resource(emotions[calculate_happiness()]);
	
	bitmap_layer_set_bitmap(face_layer, face_icon);
	layer_mark_dirty(bitmap_layer_get_layer(face_layer));
}

void tick_handler(struct tm *t, TimeUnits units){
	pubhour = t->tm_hour;
	refresh();
}

struct tm *get_tm(){
	struct tm *t;
  	time_t temp;        
  	temp = time(NULL);        
  	t = localtime(&temp);
	
	return t;
}

void bt_handler(bool connected){
	refresh();
}

void battery_handler(BatteryChargeState state){
	refresh();
}

void shake_handler(AccelAxisType axis, int32_t direction){
	if(!is_animating()){
		data_layer_show_content((int)calculate_happiness(), emotions_stack_top, get_tm());
	}
}

void window_load(Window *window){	
	Layer *window_layer = window_get_root_layer(window);

	face_layer = bitmap_layer_create(GRect(0, 0, 144, 168));
	bitmap_layer_set_bitmap(face_layer, face_icon);
	layer_add_child(window_layer, bitmap_layer_get_layer(face_layer));

	outline_layer = layer_create(GRect(0, 0, 144, 168));
	layer_set_update_proc(outline_layer, outline_proc);
	layer_add_child(window_layer, outline_layer);
	
	data_layer_init(window);
	
	struct tm *t = get_tm();
	tick_handler(t, MINUTE_UNIT);
}

void window_unload(Window *window){
	bitmap_layer_destroy(face_layer);
	gbitmap_destroy(face_icon);
}

void init(){
	window = window_create();
	window_set_window_handlers(window, (WindowHandlers){
		.load = window_load,
		.unload = window_unload,
	});
	tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
	bluetooth_connection_service_subscribe(bt_handler);
	battery_state_service_subscribe(battery_handler);
	accel_tap_service_subscribe(shake_handler);
	
	window_stack_push(window, true);
}

void deinit(){
	window_destroy(window);
}

int main(){
	init();
	app_event_loop();
	deinit();
}