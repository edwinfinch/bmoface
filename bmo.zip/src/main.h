#include <pebble.h>
#pragma once

Window *window;
BitmapLayer *face_layer;
Layer *outline_layer;
GBitmap *face_icon;

int pubhour = 0;

uint32_t emotions[2] = {
	RESOURCE_ID_IMAGE_RANDOM_2,
	RESOURCE_ID_IMAGE_BTDIS,
};