#include <pebble.h>
#pragma once

typedef struct DataLayer {
	TextLayer *date;
	TextLayer *time;
	TextLayer *bluetooth;
	TextLayer *battery;
	Layer *root;
}DataLayer;

void data_layer_init(Window *window);
void data_layer_deinit();
bool is_animating();
void data_layer_show_content(int happiness, int stack_top, struct tm *t);