#include <pebble.h>
#include "data_layer.h"

DataLayer data_layer;
bool animating = false;
AppTimer *animating_timer;

static char *bools[2] = {
		"isn't", "is"
	};

bool is_animating(){
	return animating;
}

void animating_callback(){
	animating = false;
}

void stopped(Animation *anim, bool finished, void *context){
    property_animation_destroy((PropertyAnimation*) anim);
}
 
void animate_layer(Layer *layer, GRect *start, GRect *finish, int duration, int delay){
    PropertyAnimation *anim = property_animation_create_layer_frame(layer, start, finish);
     
    animation_set_duration((Animation*) anim, duration);
    animation_set_delay((Animation*) anim, delay);
     
    AnimationHandlers handlers = {
        .stopped = (AnimationStoppedHandler) stopped
    };
    animation_set_handlers((Animation*) anim, handlers, NULL);
     
    animation_schedule((Animation*) anim);
}

void dtalay_root_proc(Layer *layer, GContext *ctx){
	graphics_context_set_fill_color(ctx, GColorBlack);
	graphics_fill_rect(ctx, GRect(0, 0, 144, 168), 0, GCornerNone);
}

void data_layer_init(Window *window){
	data_layer.root = layer_create(GRect(0, 168, 144, 168));
	layer_set_update_proc(data_layer.root, dtalay_root_proc);
	layer_add_child(window_get_root_layer(window), data_layer.root);
	layer_mark_dirty(data_layer.root);
	
	data_layer.time = text_layer_create(GRect(0, 0, 144, 168));
	text_layer_set_font(data_layer.time, fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD));
	text_layer_set_text_color(data_layer.time, GColorBlack);
	text_layer_set_text(data_layer.time, "Time: null!");
	layer_add_child(data_layer.root, text_layer_get_layer(data_layer.time));
	
	data_layer.date = text_layer_create(GRect(0, 30, 144, 168));
	text_layer_set_font(data_layer.date, fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD));
	text_layer_set_text_color(data_layer.date, GColorBlack);
	text_layer_set_text(data_layer.date, "October 7th, 2014");
	layer_add_child(data_layer.root, text_layer_get_layer(data_layer.date));
	
	data_layer.bluetooth = text_layer_create(GRect(0, 60, 144, 168));
	text_layer_set_font(data_layer.bluetooth, fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD));
	text_layer_set_text_color(data_layer.bluetooth, GColorBlack);
	text_layer_set_text(data_layer.bluetooth, "Bluetooth null...");
	layer_add_child(data_layer.root, text_layer_get_layer(data_layer.bluetooth));
	
	data_layer.battery = text_layer_create(GRect(0, 90, 144, 168));
	text_layer_set_font(data_layer.battery, fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD));
	text_layer_set_text_color(data_layer.battery, GColorBlack);
	text_layer_set_text(data_layer.battery, "Battery null...");
	layer_add_child(data_layer.root, text_layer_get_layer(data_layer.battery));
}

void data_layer_deinit(){
	
}

void data_layer_show_content(int happiness, int stack_top, struct tm *t){
	static char buffer[] = "Happiness: 10/10.";
	if(clock_is_24h_style()){
		strftime(buffer, sizeof(buffer), "%H:%M", t);
   	}
   	else{
		strftime(buffer,sizeof(buffer), "%I:%M", t);
	}	
	text_layer_set_text(data_layer.time, buffer);
	
	static char d_buffer[] = "September 26th, 2014.";
	strftime(d_buffer, sizeof(d_buffer), "%B %d, %Y", t);
	text_layer_set_text(data_layer.date, d_buffer);
	
	BatteryChargeState state = battery_state_service_peek();
	int percent = state.charge_percent;
	bool charging = state.is_charging;
	static char bat_buffer[] = "Battery is 70% and isn't charging";
	snprintf(bat_buffer, sizeof(bat_buffer), "Battery is %d%% and %s charging", percent, bools[charging]);
	text_layer_set_text(data_layer.battery, bat_buffer);
	
	bool connected = bluetooth_connection_service_peek();
	if(connected){
		text_layer_set_text(data_layer.bluetooth, "Bluetooth is on");
	}
	else{
		text_layer_set_text(data_layer.bluetooth, "Bluetooth is off");
	}
	
	animate_layer(data_layer.root, &GRect(0, 168, 144, 168), &GRect(0, 0, 144, 168), 700, 0);
	animate_layer(data_layer.root, &GRect(0, 0, 144, 168), &GRect(0, 168, 144, 168), 700, 6000);
	
	animating = true;
	animating_timer = app_timer_register(7000, animating_callback, NULL);
}